//
//  Alert.swift
//  Lunch Screen
//
//  Created by Mina on 3/19/19.
//  Copyright © 2019 Mina. All rights reserved.
//

import Foundation
import UIKit

extension UIViewController {
    
    func showAlert(titel:String, message:String, okTitle:String = "OK",okHandler: ((UIAlertAction)->Void)? = nil) {
        
        let alert = UIAlertController(title: titel, message: message, preferredStyle: .alert)
        alert.addAction(UIAlertAction(title: okTitle, style: .cancel, handler: okHandler))
        self.present(alert, animated: true, completion: nil)
        
    }
}


