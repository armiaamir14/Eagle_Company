//
//  ClientCell.swift
//  Eagle_System
//
//  Created by Bob Oror on 10/17/19.
//  Copyright © 2019 Bob Oror. All rights reserved.
//

import UIKit

class ClientCell: UITableViewCell {
    @IBOutlet weak var Name: UILabel!
    @IBOutlet weak var Phone: UILabel!
    
    override func awakeFromNib() {
        super.awakeFromNib()
        // Initialization code
    }

    override func setSelected(_ selected: Bool, animated: Bool) {
        super.setSelected(selected, animated: animated)

        // Configure the view for the selected state
    }

}
