//
//  DetailsCell.swift
//  Eagle_System
//
//  Created by Bob Oror on 10/16/19.
//  Copyright © 2019 Bob Oror. All rights reserved.
//

import UIKit

class DetailsCell: UITableViewCell {

    @IBOutlet weak var name: UILabel!
    
    @IBOutlet weak var Phonee: UILabel!
    
    @IBOutlet weak var UID: UILabel!
    
    override func awakeFromNib() {
        super.awakeFromNib()
        // Initialization code
    }

    override func setSelected(_ selected: Bool, animated: Bool) {
        super.setSelected(selected, animated: animated)

        // Configure the view for the selected state
    }

}

