//
//  Detailss.swift
//  Eagle_System
//
//  Created by Bob Oror on 10/16/19.
//  Copyright © 2019 Bob Oror. All rights reserved.
//

import UIKit
import Firebase
import FirebaseDatabase


class Detailss: UITableViewController {

    
     var name2 = [String]()
     var phone = [String]()
     var UID = [String]()
       
    let ref = Database.database().reference().child("driver")
    let ref2 = Database.database().reference()
    
    override func tableView(_ tableView: UITableView, numberOfRowsInSection section: Int) -> Int {
           // #warning Incomplete implementation, return the number of rows
           return name2.count
        
           
       }

       
       override func tableView(_ tableView: UITableView, cellForRowAt indexPath: IndexPath) -> UITableViewCell {
           let cell = tableView.dequeueReusableCell(withIdentifier: "cell", for: indexPath) as! DetailsCell
           
           cell.name.text = name2[indexPath.row]
        cell.Phonee.text = phone[indexPath.row]
        
        
           
           return cell
       }
       
    
    override func viewDidLoad() {
        super.viewDidLoad()
        loadData()
       

        
        
        
    }

    // MARK: - Table view data source
    
    
    
    private func loadData() {
    ref.observe(.value) { (snapshot: DataSnapshot) in
        self.name2=[]
        
        if let data = snapshot.value as? [String: AnyObject] {
            for value in data.values {
                
                if let comment1 = value["Name"] as? String {
                    
                    self.name2.append(comment1)
//                    print(self.name2)
                   }
                if let comment2 = value["Phone"] as? String{
                    
                    self.phone.append(comment2)
                }
                if let comment3 = value["UID"] as? String{
                    self.UID.append(comment3)
                }
                
                
            }
            
            self.tableView.reloadData()

        }
        }
    }
  
    override func tableView(_ tableView: UITableView, didSelectRowAt indexPath: IndexPath) {
        let vc = storyboard?.instantiateViewController(identifier: "Profile") as? Profile
        vc?.namee = name2[indexPath.row]
        vc?.phonee = phone[indexPath.row]
        vc?.uid = UID[indexPath.row]
        
        
        
        
        self.navigationController?.pushViewController(vc!, animated: true)
        
    }

    /*
    // Override to support conditional editing of the table view.
    override func tableView(_ tableView: UITableView, canEditRowAt indexPath: IndexPath) -> Bool {
        // Return false if you do not want the specified item to be editable.
        return true
    }
    */

    /*
    // Override to support editing the table view.
    override func tableView(_ tableView: UITableView, commit editingStyle: UITableViewCell.EditingStyle, forRowAt indexPath: IndexPath) {
        if editingStyle == .delete {
            // Delete the row from the data source
            tableView.deleteRows(at: [indexPath], with: .fade)
        } else if editingStyle == .insert {
            // Create a new instance of the appropriate class, insert it into the array, and add a new row to the table view
        }    
    }
    */

    /*
    // Override to support rearranging the table view.
    override func tableView(_ tableView: UITableView, moveRowAt fromIndexPath: IndexPath, to: IndexPath) {

    }
    */

    /*
    // Override to support conditional rearranging of the table view.
    override func tableView(_ tableView: UITableView, canMoveRowAt indexPath: IndexPath) -> Bool {
        // Return false if you do not want the item to be re-orderable.
        return true
    }
    */

    /*
    // MARK: - Navigation

    // In a storyboard-based application, you will often want to do a little preparation before navigation
    override func prepare(for segue: UIStoryboardSegue, sender: Any?) {
        // Get the new view controller using segue.destination.
        // Pass the selected object to the new view controller.
    }
    */

}
