//
//  Home.swift
//  Eagle_System
//
//  Created by Bob Oror on 10/16/19.
//  Copyright © 2019 Bob Oror. All rights reserved.
//

import UIKit
import Firebase
import FirebaseDatabase

class AddDriver: UIViewController {

    @IBOutlet weak var Name: UITextField!
    @IBOutlet weak var email: UITextField!
    @IBOutlet weak var Pass: UITextField!
    @IBOutlet weak var Phone: UITextField!
    @IBOutlet weak var ID: UITextField!
 
    
    let ref = Database.database().reference().child("driver")
    
    override func viewDidLoad() {
        self.navigationController?.isNavigationBarHidden = true
        super.viewDidLoad()
        
        
        

        // Do any additional setup after loading the view.
    }
    
    // register button  and store data
    
    @IBAction func Register_Button(_ sender: Any) {
        
        guard let name = Name.text , name != ""   else {
            showAlert(titel: "ALERT", message: "name is empty")
            return
        }
        guard let maiil = email.text , maiil != ""   else {
                          showAlert(titel: "ALERT", message: "Email is empty")
                          return
                      }
       
        
        guard let password = Pass.text , password != ""   else {
                   showAlert(titel: "ALERT", message: "password is empty")
                   return
               }
        
        guard let Phoone = Phone.text , Phoone != ""   else {
                   showAlert(titel: "ALERT", message: "phone is empty")
                   return
               }
        
        guard let iiD = ID.text , iiD != ""   else {
                   showAlert(titel: "ALERT", message: "ID is empty")
                   return
               }
        
        // authuntication
        
        if  let emaiil = email.text, let passwoord = Pass.text {
                Auth.auth().createUser(withEmail: emaiil, password: passwoord) { (user, error) in
                    if error == nil {
                        if let user = user {
                            
                                let uid = user.user.uid
                                
                            self.ref.child(uid).setValue(["Name":"\(self.Name.text!)", "Email":"\(self.email.text!)" ,"Password":"\(self.Pass.text!)", "Phone":"\(self.Phone.text!)" , "ID":"\(self.ID.text!)", "IsDriver":"TRUE", "UID":"\(uid)"])
                                
                            self.showAlert(titel: "Success", message: "User Created")
                            
                            
                            print(user.user.providerID)
                            print("USER CREATED!!!!!!!!!!!1")
                        }
                    }
                }
            }
        
        
        
        
    }
    /*
    // MARK: - Navigation

    // In a storyboard-based application, you will often want to do a little preparation before navigation
    override func prepare(for segue: UIStoryboardSegue, sender: Any?) {
        // Get the new view controller using segue.destination.
        // Pass the selected object to the new view controller.
    }
    */

}

