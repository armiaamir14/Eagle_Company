//
//  Profile.swift
//  Eagle_System
//
//  Created by Bob Oror on 10/18/19.
//  Copyright © 2019 Bob Oror. All rights reserved.
//

import UIKit
import Firebase
import FirebaseDatabase

class Profile: UIViewController {

    @IBOutlet weak var Phone: UILabel!
    @IBOutlet weak var Name: UILabel!
    @IBOutlet weak var UID: UILabel!
    
    let ref = Database.database().reference().child("driver")
    
    var namee = ""
    var phonee = ""
    var uid = ""

    
    
    override func viewDidLoad() {
        super.viewDidLoad()
        print(namee)
        Name.text = "\(namee)"
        Phone.text = "\(phonee)"
        UID.text = "\(uid)"


    
        
        
        // Do any additional setup after loading the view.
    }
    
    @IBAction func Del(_ sender: Any) {
        
        let alert = UIAlertController(title: "Warrning", message: "Do you want to delete this driver", preferredStyle: .alert)
        alert.addAction(UIAlertAction(title: "Cancel", style: .destructive, handler: nil))
        alert.addAction(UIAlertAction(title: "Ok", style: .default, handler: { (action: UIAlertAction) in
            self.ref.child("\(self.uid)").removeValue()
            self.dismiss(animated: true, completion: nil)
        }))
        
        self.present(alert, animated: true, completion: nil)
        
    }
    
    
    

}
