//
//  ClientProfile.swift
//  Eagle_System
//
//  Created by Bob Oror on 10/28/19.
//  Copyright © 2019 Bob Oror. All rights reserved.
//

import UIKit

class ClientProfile: UIViewController {
    
    
    @IBOutlet weak var Name: UILabel!
    @IBOutlet weak var Phone: UILabel!
    
    var namee = ""
    var phonee = ""
    
    override func viewDidLoad() {
        super.viewDidLoad()
        Name.text = "\(namee)"
        Phone.text = "\(phonee)"

        // Do any additional setup after loading the view.
    }
    

    /*
    // MARK: - Navigation

    // In a storyboard-based application, you will often want to do a little preparation before navigation
    override func prepare(for segue: UIStoryboardSegue, sender: Any?) {
        // Get the new view controller using segue.destination.
        // Pass the selected object to the new view controller.
    }
    */

}
