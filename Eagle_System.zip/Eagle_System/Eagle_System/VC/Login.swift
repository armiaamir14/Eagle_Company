//
//  Login.swift
//  Eagle_System
//
//  Created by Bob Oror on 10/16/19.
//  Copyright © 2019 Bob Oror. All rights reserved.
//

import UIKit

class Login: UIViewController {

    @IBOutlet weak var Password: UITextField!
    @IBOutlet weak var Email: UITextField!
    
    
    override func viewDidLoad() {
        super.viewDidLoad()
        self.navigationController?.isNavigationBarHidden = true

        // Do any additional setup after loading the view.
    }
    
    
    @IBAction func login_button(_ sender: Any) {
        if Email.text == "admin" && Password.text == "11111111" {
            
                        let sb = UIStoryboard(name: "Main", bundle: nil)
                        let vc = sb.instantiateViewController(withIdentifier: "Main")
                        let navC = UINavigationController(rootViewController: vc)
                        self.present(navC, animated: true, completion: nil)
                    
            print("/////passed/////")
        }
        else{
            showAlert(titel: "error", message: "you are not admin")
        }
        
        
        }
    }
    

    /*
    // MARK: - Navigation

    // In a storyboard-based application, you will often want to do a little preparation before navigation
    override func prepare(for segue: UIStoryboardSegue, sender: Any?) {
        // Get the new view controller using segue.destination.
        // Pass the selected object to the new view controller.
    }
    */


